﻿using SLDisMacros.Interfaces;

public class Script
{
    public void Run(IEngine engine)
    {

    }
}